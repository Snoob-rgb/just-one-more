import { BLOCK_TYPES, DNR_IDS } from "./constants.js"

const TYPE_MAP = {
  script: "script",
  image: "image",
  stylesheet: "stylesheet",
  font: "font",
  media: "media",
  xmlhttprequest: "xmlhttprequest",
  xhr: "xmlhttprequest",
  subdocument: "sub_frame",
  ping: "ping",
  websocket: "websocket",
  object: "object",
  other: "other",
}

function parseOptions(raw) {
  if (!raw) return { types: BLOCK_TYPES, domain: null, thirdParty: null }
  const parts = raw.split(",").map((p) => p.trim().toLowerCase())
  const types = []
  let thirdParty = null
  let domain = null

  for (const part of parts) {
    if (part === "third-party") thirdParty = true
    else if (part === "~third-party" || part === "first-party") thirdParty = false
    else if (part.startsWith("domain=")) domain = part.slice(7).split("|")[0].replace(/^~/, "")
    else if (TYPE_MAP[part]) types.push(TYPE_MAP[part])
  }

  return {
    types: types.length ? types : BLOCK_TYPES,
    thirdParty,
    domain,
  }
}

/**
 * Convert simple EasyList network filters to DNR rules.
 * Cosmetic filters (## / #@#) are returned separately.
 */
export function parseFilterList(text, startId) {
  const network = []
  const cosmetic = []
  let id = startId

  for (const lineRaw of text.split(/\r?\n/)) {
    const line = lineRaw.trim()
    if (!line || line.startsWith("!") || line.startsWith("[")) continue
    if (line.startsWith("@@")) continue

    if (line.includes("#@#")) continue
    if (line.includes("##")) {
      const selector = line.split("##")[1]?.trim()
      if (selector && !selector.includes("+js(") && selector.length < 180) {
        cosmetic.push(selector)
      }
      continue
    }

    if (id > DNR_IDS.IMPORT_END) break

    const [patternRaw, optionsRaw] = line.split("$")
    let pattern = patternRaw.trim()
    if (!pattern || pattern.startsWith("/") && pattern.endsWith("/")) continue
    if (pattern.includes("*") && pattern.length < 4) continue

    const opts = parseOptions(optionsRaw)

    if (pattern.startsWith("||")) {
      // already DNR-compatible-ish
    } else if (pattern.startsWith("|https://") || pattern.startsWith("|http://")) {
      pattern = pattern.slice(1)
    } else if (pattern.startsWith("|")) {
      continue
    } else if (!pattern.includes("://") && !pattern.startsWith("||")) {
      if (/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(pattern.replace(/\^/g, ""))) {
        pattern = `||${pattern.replace(/\^$/g, "")}^`
      } else {
        continue
      }
    }

    if (pattern.length > 200) continue

    const condition = {
      urlFilter: pattern,
      resourceTypes: opts.types,
    }
    if (opts.thirdParty === true) condition.domainType = "thirdParty"
    if (opts.thirdParty === false) condition.domainType = "firstParty"
    if (opts.domain) condition.initiatorDomains = [opts.domain.replace(/^www\./, "")]

    network.push({
      id: id++,
      priority: 5,
      action: { type: "block" },
      condition,
    })
  }

  return { network, cosmetic: [...new Set(cosmetic)].slice(0, 4000) }
}
