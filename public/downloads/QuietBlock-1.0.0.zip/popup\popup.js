const $ = (id) => document.getElementById(id)

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  return tab
}

function render(state) {
  $("enabled").checked = state.settings.enabled
  $("host").textContent = state.host || "onglet interne"
  $("pageBlocked").textContent = state.pageBlocked || 0
  $("pageNet").textContent = state.pageNet || 0
  $("pageCosmetic").textContent = state.pageCosmetic || 0
  $("lifetime").textContent =
    `${(state.stats.lifetimeBlocked + state.stats.lifetimeCosmetic).toLocaleString("fr-FR")} bloqués au total`

  const siteBtn = $("toggleSite")
  const usable = Boolean(state.host) && !state.url?.startsWith("chrome")
  siteBtn.disabled = !usable || !state.settings.enabled
  siteBtn.textContent = state.pageWhitelisted ? "Rebloquer ce site" : "Autoriser ce site"

  if (!state.settings.enabled) {
    $("status").textContent = "Blocage général désactivé."
    $("status").className = "status warn"
  } else if (state.pageWhitelisted) {
    $("status").textContent = "Ce site est en liste blanche."
    $("status").className = "status warn"
  } else {
    $("status").textContent = "Filtres actifs sur cette page."
    $("status").className = "status"
  }
}

async function refresh() {
  const tab = await activeTab()
  const state = await chrome.runtime.sendMessage({
    type: "qb:get-state",
    tabId: tab?.id,
    url: tab?.url,
  })
  render(state)
  return { tab, state }
}

$("enabled").addEventListener("change", async (e) => {
  await chrome.runtime.sendMessage({ type: "qb:set-enabled", enabled: e.target.checked })
  const tab = await activeTab()
  if (tab?.id) chrome.tabs.reload(tab.id)
  refresh()
})

$("toggleSite").addEventListener("click", async () => {
  const { tab, state } = await refresh()
  if (!state.host) return
  await chrome.runtime.sendMessage({ type: "qb:toggle-site", host: state.host })
  if (tab?.id) chrome.tabs.reload(tab.id)
  refresh()
})

$("openOptions").addEventListener("click", () => {
  chrome.runtime.openOptionsPage()
})

refresh()
