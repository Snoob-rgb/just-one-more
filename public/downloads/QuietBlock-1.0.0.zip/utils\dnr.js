import {
  BLOCK_TYPES,
  DNR_IDS,
  RESOURCE_TYPES,
  RULESET_IDS,
} from "./constants.js"

function siteAllowRule(whitelist) {
  if (!whitelist.length) return null
  return {
    id: DNR_IDS.SITE_ALLOW,
    priority: 10_000,
    action: { type: "allowAllRequests" },
    condition: {
      initiatorDomains: whitelist,
      resourceTypes: RESOURCE_TYPES,
    },
  }
}

function globalAllowRule() {
  return {
    id: DNR_IDS.GLOBAL_ALLOW,
    priority: 20_000,
    action: { type: "allowAllRequests" },
    condition: { resourceTypes: RESOURCE_TYPES },
  }
}

function customBlockRules(domains) {
  return domains.slice(0, DNR_IDS.CUSTOM_BLOCK_END - DNR_IDS.CUSTOM_BLOCK_START + 1).map(
    (domain, i) => ({
      id: DNR_IDS.CUSTOM_BLOCK_START + i,
      priority: 50,
      action: { type: "block" },
      condition: {
        urlFilter: `||${domain}^`,
        resourceTypes: BLOCK_TYPES,
      },
    }),
  )
}

export async function syncDnrFromSettings(settings) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules()
  const removeIds = existing
    .map((r) => r.id)
    .filter(
      (id) =>
        id === DNR_IDS.GLOBAL_ALLOW ||
        id === DNR_IDS.SITE_ALLOW ||
        (id >= DNR_IDS.CUSTOM_BLOCK_START && id <= DNR_IDS.CUSTOM_BLOCK_END),
    )

  const addRules = []
  if (!settings.enabled) {
    addRules.push(globalAllowRule())
  } else if (settings.whitelist.length) {
    const allow = siteAllowRule(settings.whitelist)
    if (allow) addRules.push(allow)
  }
  if (settings.enabled && settings.customBlockDomains.length) {
    addRules.push(...customBlockRules(settings.customBlockDomains))
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules,
  })

  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: settings.enabled
      ? RULESET_IDS.filter((id) => settings.lists[id])
      : [],
    disableRulesetIds: settings.enabled
      ? RULESET_IDS.filter((id) => !settings.lists[id])
      : RULESET_IDS,
  })
}

export async function replaceImportedRules(rules) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules()
  const removeIds = existing
    .map((r) => r.id)
    .filter((id) => id >= DNR_IDS.IMPORT_START && id <= DNR_IDS.IMPORT_END)

  const capped = rules.slice(0, DNR_IDS.IMPORT_END - DNR_IDS.IMPORT_START + 1)
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules: capped,
  })
  return capped.length
}

export async function clearImportedRules() {
  const existing = await chrome.declarativeNetRequest.getDynamicRules()
  const removeIds = existing
    .map((r) => r.id)
    .filter((id) => id >= DNR_IDS.IMPORT_START && id <= DNR_IDS.IMPORT_END)
  if (removeIds.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds })
  }
}
