# QuietBlock

Bloqueur de publicités Manifest V3 — local, moderne, sans télémétrie.  
Studio : Just One More.

## 1. Arborescence

```
QuietBlock/
├── manifest.json                 # Manifest V3 : permissions, DNR, content scripts
├── README.md
├── _locales/fr|en/messages.json  # Nom / description i18n
├── background/
│   └── service-worker.js         # État, whitelist, stats, import EasyList, badge
├── content/
│   ├── blocker.js                # Masquage DOM + MutationObserver (isolated world)
│   ├── cosmetic.css              # Sélecteurs pubs / widgets natifs
│   └── page-guard.js             # window.open + clics pubs (MAIN world)
├── popup/                        # Interrupteur, stats page, allowlist 1 clic
├── options/                      # Listes, whitelist, domaines custom, update filtres
├── rules/
│   ├── static-ads.json           # Règles DNR embarquées (pubs)
│   ├── static-trackers.json      # Trackers / analytics
│   ├── static-annoyances.json    # Pop-ups, push, overlays
│   └── cosmetic-extra.json       # Placeholder ressources accessibles
├── utils/
│   ├── constants.js              # IDs DNR, sources EasyList, défauts
│   ├── storage.js                # chrome.storage.local
│   ├── dnr.js                    # Sync règles dynamiques + rulesets
│   └── easylist.js               # Parse EasyList → DNR + sélecteurs ##
├── icons/                        # 16 / 32 / 48 / 128 (+ variantes off)
├── test/demo.html                # Page de test locale
└── tools/build-rules.mjs         # Régénère les JSON DNR
```

### Rôle des fichiers clés

| Fichier | Rôle |
|---|---|
| `manifest.json` | Déclare MV3, DNR statique, permissions minimales, popup / options |
| `background/service-worker.js` | Cerveau : on/off, whitelist, compteurs, import de listes, badge |
| `utils/dnr.js` | Traduit les réglages en règles `allowAllRequests` / block dynamiques |
| `utils/easylist.js` | Convertit les filtres réseau simples EasyList vers DNR |
| `rules/static-*.json` | Listes embarquées (domaines ads / trackers / annoyances) |
| `content/blocker.js` | Cache les éléments HTML pub détectables, compte les hits cosmétiques |
| `content/cosmetic.css` | CSS injecté dès `document_start` |
| `content/page-guard.js` | Empêche pop-ups / pop-under vers des domaines pub connus |
| `popup/*` | UI rapide : switch global, stats, autoriser ce site |
| `options/*` | Gestion listes, whitelist, domaines custom, mise à jour EasyList |

## 2. Fonctionnement du filtrage

QuietBlock combine **trois couches** :

1. **Réseau (DNR / Manifest V3)**  
   `declarativeNetRequest` bloque les requêtes vers des domaines et chemins publicitaires / trackers **avant** qu’elles n’atteignent la page.  
   C’est le moteur principal, performant (géré par le navigateur, pas par du JS page).

2. **Cosmétique (CSS + DOM)**  
   Même si une pub est servie depuis le **même domaine** que le site, le CSS et le content script masquent les bannières, `ins.adsbygoogle`, GPT, Taboola, Outbrain, overlays, etc.

3. **Garde-fou page (MAIN world)**  
   `window.open` et certains liens `_blank` vers des domaines ads sont annulés (pop-up / pop-under).

**Liste blanche** : règle dynamique `allowAllRequests` prioritaire pour les `initiatorDomains` autorisés.  
**Off global** : une règle `allowAllRequests` encore plus prioritaire.  
**Listes** ads / trackers / annoyances : activables séparément via `updateEnabledRulesets`.  
**Mise à jour EasyList** : téléchargement depuis `easylist.to`, conversion des filtres `||domaine^` (et équivalents simples) en règles dynamiques (plafond Chrome ~4000) + sélecteurs `##`.

Aucune télémétrie : pas d’appel maison, pas d’historique stocké, seulement des compteurs locaux.

## 3. Installation (Chrome / Edge / Brave)

1. Ouvre `chrome://extensions` (ou `edge://extensions`).
2. Active **Mode développeur**.
3. **Charger l’extension non empaquetée**.
4. Sélectionne le dossier `QuietBlock`.
5. Épingle l’icône QuietBlock dans la barre.

Firefox récent (MV3) : `about:debugging` → « Ce Firefox » → « Charger un module temporaire » → `manifest.json`.  
Certaines APIs (`onRuleMatchedDebug`, badge text color) sont plus complètes sur Chromium.

## 4. Tests

### A. Page de démo locale

1. Charge l’extension.
2. Ouvre `test/demo.html` dans le navigateur (`fichier://` ou via un petit serveur).
3. Vérifie :
   - les blocs rouges (`.adsbygoogle`, `#banner-ad`, Outbrain, Taboola) sont masqués ;
   - l’iframe `doubleclick.net` ne charge pas ;
   - le badge QuietBlock affiche un compteur ;
   - le popup montre des hits « éléments » et/ou « requêtes ».

Astuce : un serveur local évite les restrictions `file://` :

```bash
cd QuietBlock
npx --yes serve test -l 5500
```

Puis ouvre `http://localhost:5500/demo.html`.

### B. Site réel

1. Va sur un site très monétisé (média, streaming gratuit, forum).
2. Ouvre DevTools → Network : les appels `googlesyndication`, `doubleclick`, `taboola`, etc. doivent être `(blocked:other)` / `ERR_BLOCKED_BY_CLIENT`.
3. Clique **Autoriser ce site** dans le popup → recharge → les pubs reviennent.
4. Désactive le switch global → tout passe.
5. Options → décoche **Trackers** → GA/GTM peuvent réapparaître tout en gardant les ads bloquées.

### C. Mise à jour des listes

1. Options → **Mettre à jour EasyList + EasyPrivacy** (il faut Internet).
2. Vérifie le message « X règles réseau ».
3. Recharge un site pub-lourd : le blocage doit s’élargir.

## 5. Limites connues

- **Pubs first-party / in-stream** : une pub servie depuis le même domaine que le contenu (ex. player vidéo maison, « recos » éditoriales) échappe souvent au DNR. Le cosmétique aide, mais ce n’est pas magique.
- **YouTube / streaming** : les mid-rolls sont très intégrés au player ; MV3 ne permet plus le `webRequestBlocking` classique. QuietBlock réduit le tracking et une partie des `pagead`, pas un « skip ad » complet.
- **Anti-adblock** : certains sites détectent l’absence de `adsbygoogle` et affichent un mur. Whitelist le site ou négocie côté contenu.
- **Faux positifs** : des classes du type `ad` dans un mot (`header`, `download`) sont filtrées avec prudence, mais un site mal nommé peut cacher un bloc utile → whitelist.
- **EasyList importé** : seulement les filtres réseau simples + `##`. Pas de scriptlets uBlock (`+js(...)`), pas de `:has()` avancé selon le moteur CSS.
- **Quota DNR** : Chrome limite le nombre de règles dynamiques. L’import garde les premières milliers de règles convertibles.
- **Compteurs réseau** : le détail par règle (`onRuleMatchedDebug`) est surtout fiable en extension **non empaquetée**. En packagé, les compteurs cosmétiques + lifetime restent disponibles.
- **Notifications web** : on filtre les prompts clairement publicitaires ; une notif légitime du site n’est pas une « pub réseau ».
- **CSP des pages** : le content script isolated + DNR passent ; d’éventuelles injections supplémentaires pourraient être limitées par la CSP du site.

## 6. Régénérer les règles embarquées

```bash
node tools/build-rules.mjs
```

## 7. Permissions (pourquoi)

| Permission | Pourquoi |
|---|---|
| `declarativeNetRequest*` | Bloquer les requêtes ads/trackers |
| `storage` | Whitelist, réglages, compteurs locaux |
| `tabs` | Savoir le domaine de l’onglet actif (popup) |
| `scripting` | APIs d’extension modernes / rechargement de logique |
| `alarms` | Réveil léger du service worker |
| `host_permissions <all_urls>` | Filtrer tous les sites (standard adblocker) |

Rien n’est envoyé à un serveur QuietBlock / Just One More.

## Licence

Usage personnel / studio Just One More. Les listes EasyList / EasyPrivacy restent sous leurs licences respectives (ne pas les republier comme si elles t’appartenaient).
