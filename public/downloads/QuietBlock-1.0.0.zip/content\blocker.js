(() => {
  const AD_IFRAME_HINTS = [
    "doubleclick.net",
    "googlesyndication",
    "googletagservices",
    "amazon-adsystem",
    "adnxs.com",
    "criteo.",
    "taboola.",
    "outbrain.",
    "mgid.",
    "revcontent.",
    "zergnet.",
    "popads.",
    "propellerads",
    "exoclick",
    "juicyads",
    "adservice.google",
    "securepubads",
    "imasdk.googleapis",
  ]

  const AD_ATTR_HINTS = [
    "ad-slot",
    "adslot",
    "adsbygoogle",
    "sponsored",
    "taboola",
    "outbrain",
    "revcontent",
    "mgid",
    "nativead",
    "dfp-ad",
  ]

  let enabled = true
  let extraSelectors = []
  let hiddenCount = 0
  let flushTimer = 0
  let extraStyle = null

  const report = (n) => {
    hiddenCount += n
    if (flushTimer) return
    flushTimer = setTimeout(() => {
      const count = hiddenCount
      hiddenCount = 0
      flushTimer = 0
      if (count > 0) {
        chrome.runtime.sendMessage({ type: "qb:cosmetic-hits", count }).catch(() => {})
      }
    }, 400)
  }

  const looksLikeAd = (el) => {
    if (!(el instanceof Element)) return false
    if (el.closest("main article, [role='main'] article, .post-content, .entry-content")) {
      const tag = el.tagName
      if (tag === "P" || tag === "H1" || tag === "H2" || tag === "H3") return false
    }
    const id = (el.id || "").toLowerCase()
    const cls = (typeof el.className === "string" ? el.className : "").toLowerCase()
    const aria = (el.getAttribute("aria-label") || "").toLowerCase()
    const blob = `${id} ${cls} ${aria}`
    if (/(^|[-_])ads?([-_]|$)/.test(id) || /(^|[-_\s])ads?([-_\s]|$)/.test(cls)) {
      if (!/(header|head|breadcrumb|download|pad|badge|radio|shadow|load)/.test(blob)) return true
    }
    if (AD_ATTR_HINTS.some((h) => blob.includes(h))) return true
    if (aria.includes("advert") || aria.includes("publicité") || aria.includes("annonce sponsor")) return true
    if (el.tagName === "IFRAME") {
      const src = (el.getAttribute("src") || el.src || "").toLowerCase()
      if (AD_IFRAME_HINTS.some((h) => src.includes(h))) return true
    }
    if (el.tagName === "INS" && el.classList.contains("adsbygoogle")) return true
    return false
  }

  const hide = (el) => {
    if (!el || el.dataset.qbHidden === "1") return false
    el.dataset.qbHidden = "1"
    el.style.setProperty("display", "none", "important")
    el.style.setProperty("visibility", "hidden", "important")
    el.style.setProperty("pointer-events", "none", "important")
    return true
  }

  const scan = (root = document) => {
    if (!enabled || !root) return
    let n = 0
    const nodes = root.querySelectorAll
      ? root.querySelectorAll("iframe, ins, aside, div, section, img, a")
      : []
    for (const el of nodes) {
      if (looksLikeAd(el) && hide(el)) n += 1
    }
    if (extraSelectors.length) {
      try {
        const extra = root.querySelectorAll(extraSelectors.join(","))
        for (const el of extra) if (hide(el)) n += 1
      } catch {
        /* sélecteur importé invalide : ignorer */
      }
    }
    if (n) report(n)
  }

  const applyExtraCss = () => {
    if (extraStyle) extraStyle.remove()
    if (!extraSelectors.length) return
    extraStyle = document.createElement("style")
    extraStyle.setAttribute("data-quietblock", "extra")
    extraStyle.textContent = `${extraSelectors.join(",")}{display:none!important;visibility:hidden!important;}`
    ;(document.documentElement || document.head || document.body)?.appendChild(extraStyle)
  }

  const init = async () => {
    try {
      const host = location.hostname
      const res = await chrome.runtime.sendMessage({ type: "qb:should-run", host })
      enabled = Boolean(res?.run)
      extraSelectors = Array.isArray(res?.extraCosmetic) ? res.extraCosmetic.slice(0, 1500) : []
    } catch {
      enabled = true
    }
    if (!enabled) {
      document.documentElement?.classList.add("qb-disabled")
      return
    }
    applyExtraCss()
    scan(document)
    const mo = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue
          if (looksLikeAd(node) && hide(node)) report(1)
          scan(node)
        }
      }
    })
    mo.observe(document.documentElement || document, {
      childList: true,
      subtree: true,
    })
    window.addEventListener(
      "load",
      () => scan(document),
      { once: true },
    )
  }

  init()
})()
