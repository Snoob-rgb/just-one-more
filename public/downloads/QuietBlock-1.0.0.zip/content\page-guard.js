(() => {
  if (window.__quietblockGuard) return
  window.__quietblockGuard = true

  const BLOCKED = [
    "doubleclick.net",
    "googlesyndication",
    "googleadservices",
    "amazon-adsystem",
    "adnxs.com",
    "criteo.",
    "taboola.",
    "outbrain.",
    "popads.",
    "popcash.",
    "propellerads",
    "exoclick",
    "juicyads",
    "adsterra",
    "hilltopads",
    "mgid.",
    "revcontent.",
    "zergnet.",
    "adservice.google",
    "securepubads",
  ]

  const isAdUrl = (value) => {
    try {
      const href = String(value || "")
      const host = href.startsWith("http") ? new URL(href, location.href).hostname : href
      const hay = `${host} ${href}`.toLowerCase()
      return BLOCKED.some((n) => hay.includes(n))
    } catch {
      return false
    }
  }

  const nativeOpen = window.open.bind(window)
  window.open = function quietblockOpen(url, target, features) {
    if (isAdUrl(url) || /popunder|popup-ad|ad-popup/i.test(String(url || ""))) {
      return null
    }
    return nativeOpen(url, target, features)
  }

  document.addEventListener(
    "click",
    (event) => {
      const a = event.target?.closest?.("a[href]")
      if (!a) return
      const href = a.href || ""
      if (!isAdUrl(href)) return
      if (a.target === "_blank" || event.ctrlKey || event.metaKey || event.shiftKey) {
        event.preventDefault()
        event.stopPropagation()
      }
    },
    true,
  )

  const nativeNotification = window.Notification
  if (nativeNotification) {
    const wrapped = function QuietNotification(title, options) {
      const t = `${title} ${options?.body || ""}`.toLowerCase()
      if (/(promo|publicit|advert|sponsor|offre limitée|click here)/i.test(t)) {
        return { close() {}, addEventListener() {}, removeEventListener() {} }
      }
      return new nativeNotification(title, options)
    }
    wrapped.permission = nativeNotification.permission
    wrapped.requestPermission = nativeNotification.requestPermission.bind(nativeNotification)
    try {
      window.Notification = wrapped
    } catch {
      /* certains navigateurs rendent Notification non configurable */
    }
  }
})()
