import { DEFAULT_SETTINGS, DEFAULT_STATS } from "./constants.js"

export async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings")
  return {
    ...DEFAULT_SETTINGS,
    ...(settings || {}),
    lists: { ...DEFAULT_SETTINGS.lists, ...(settings?.lists || {}) },
    whitelist: Array.isArray(settings?.whitelist) ? settings.whitelist : [],
    customBlockDomains: Array.isArray(settings?.customBlockDomains)
      ? settings.customBlockDomains
      : [],
    extraCosmetic: Array.isArray(settings?.extraCosmetic)
      ? settings.extraCosmetic
      : [],
  }
}

export async function saveSettings(patch) {
  const current = await getSettings()
  const next = {
    ...current,
    ...patch,
    lists: { ...current.lists, ...(patch.lists || {}) },
  }
  await chrome.storage.local.set({ settings: next })
  return next
}

export async function getStats() {
  const { stats } = await chrome.storage.local.get("stats")
  return { ...DEFAULT_STATS, ...(stats || {}) }
}

export async function saveStats(patch) {
  const current = await getStats()
  const next = { ...current, ...patch }
  await chrome.storage.local.set({ stats: next })
  return next
}

export function normalizeHost(input) {
  if (!input) return ""
  try {
    const url = input.includes("://") ? new URL(input) : new URL(`https://${input}`)
    return url.hostname.replace(/^www\./, "").toLowerCase()
  } catch {
    return String(input)
      .trim()
      .replace(/^www\./, "")
      .toLowerCase()
  }
}

export function hostMatchesWhitelist(host, whitelist) {
  if (!host) return false
  const h = host.replace(/^www\./, "").toLowerCase()
  return whitelist.some((entry) => {
    const e = normalizeHost(entry)
    return h === e || h.endsWith(`.${e}`)
  })
}
