(() => {
  if (!/(^|\.)twitch\.tv$/i.test(location.hostname)) return

  const hideSelectors = [
    '[data-a-target="video-ad-label"]',
    '[data-a-target="video-ad-countdown"]',
    '[data-a-target="ad-banner"]',
    '[data-test-selector*="ad-banner"]',
    '[data-test-selector*="AdBanner"]',
    '[data-test-selector="sad-overlay"]',
    '.video-ads',
    '.avp-ad',
    '[aria-label="Advertisement"]',
    '[aria-label="Publicité"]',
  ]

  let enabled = true
  let twitchOn = true
  let hidden = 0
  let flush = 0

  const report = (n) => {
    hidden += n
    if (flush) return
    flush = setTimeout(() => {
      const count = hidden
      hidden = 0
      flush = 0
      if (count > 0) {
        chrome.runtime.sendMessage({ type: "qb:cosmetic-hits", count }).catch(() => {})
      }
    }, 400)
  }

  const hideNode = (el) => {
    if (!(el instanceof Element) || el.dataset.qbTwitchUi === "1") return false
    el.dataset.qbTwitchUi = "1"
    el.style.setProperty("display", "none", "important")
    el.style.setProperty("visibility", "hidden", "important")
    el.style.setProperty("pointer-events", "none", "important")
    return true
  }

  const scan = (root = document) => {
    if (!enabled || !twitchOn || !root?.querySelectorAll) return
    let n = 0
    try {
      for (const el of root.querySelectorAll(hideSelectors.join(","))) {
        if (hideNode(el)) n += 1
      }
    } catch {
      /* ignore */
    }
    if (n) report(n)
  }

  const applyFlag = () => {
    const root = document.documentElement
    if (!root) return
    if (enabled && twitchOn) {
      root.dataset.qbTwitch = "on"
      try {
        localStorage.setItem("quietblock-twitch", "1")
      } catch {
        /* private mode */
      }
    } else {
      root.dataset.qbTwitch = "off"
      try {
        localStorage.setItem("quietblock-twitch", "0")
      } catch {
        /* private mode */
      }
    }
  }

  document.addEventListener("qb-twitch-hit", (event) => {
    const n = Number(event.detail?.count) || 1
    report(n)
  })

  const init = async () => {
    try {
      const res = await chrome.runtime.sendMessage({
        type: "qb:should-run",
        host: location.hostname,
      })
      enabled = Boolean(res?.run)
      twitchOn = Boolean(res?.twitch)
    } catch {
      enabled = true
      twitchOn = true
    }
    applyFlag()
    if (!enabled || !twitchOn) return
    scan(document)
    const mo = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue
          if (hideSelectors.some((sel) => {
            try {
              return node.matches?.(sel) || node.querySelector?.(sel)
            } catch {
              return false
            }
          })) {
            scan(node)
          }
        }
      }
    })
    mo.observe(document.documentElement || document, { childList: true, subtree: true })
  }

  init()
})()
