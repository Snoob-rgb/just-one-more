import { FILTER_SOURCES, DNR_IDS } from "../utils/constants.js"
import { parseFilterList } from "../utils/easylist.js"
import { replaceImportedRules, syncDnrFromSettings } from "../utils/dnr.js"
import {
  getSettings,
  getStats,
  hostMatchesWhitelist,
  normalizeHost,
  saveSettings,
  saveStats,
} from "../utils/storage.js"

const tabHits = new Map()
const tabCosmetic = new Map()

function setBadge(tabId, count) {
  const text = count > 99 ? "99+" : count > 0 ? String(count) : ""
  chrome.action.setBadgeBackgroundColor({ color: "#1f6f55", tabId })
  chrome.action.setBadgeTextColor?.({ color: "#f4fff8", tabId })
  chrome.action.setBadgeText({ text, tabId })
}

function bumpTab(tabId, kind = "net", n = 1) {
  if (!Number.isInteger(tabId) || tabId < 0) return
  if (kind === "cosmetic") {
    tabCosmetic.set(tabId, (tabCosmetic.get(tabId) || 0) + n)
  } else {
    tabHits.set(tabId, (tabHits.get(tabId) || 0) + n)
  }
  const total = (tabHits.get(tabId) || 0) + (tabCosmetic.get(tabId) || 0)
  setBadge(tabId, total)
}

async function bumpLifetime(net = 0, cosmetic = 0) {
  if (!net && !cosmetic) return
  const stats = await getStats()
  await saveStats({
    lifetimeBlocked: stats.lifetimeBlocked + net,
    lifetimeCosmetic: stats.lifetimeCosmetic + cosmetic,
  })
}

async function refreshActionIcon(tabId, url) {
  const settings = await getSettings()
  const host = normalizeHost(url || "")
  const off =
    !settings.enabled || (host && hostMatchesWhitelist(host, settings.whitelist))
  await chrome.action.setIcon({
    tabId,
    path: off
      ? {
          16: "icons/icon-off-16.png",
          32: "icons/icon-off-32.png",
          48: "icons/icon-off-48.png",
        }
      : {
          16: "icons/icon-16.png",
          32: "icons/icon-32.png",
          48: "icons/icon-48.png",
        },
  })
}

chrome.runtime.onInstalled.addListener(async () => {
  const settings = await getSettings()
  await chrome.storage.local.set({ settings })
  await syncDnrFromSettings(settings)
  chrome.alarms.create("quietblock-refresh", { periodInMinutes: 60 * 12 })
})

chrome.runtime.onStartup.addListener(async () => {
  await syncDnrFromSettings(await getSettings())
})

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "quietblock-refresh") return
  // Keep SW alive work minimal: just re-sync DNR from storage.
  await syncDnrFromSettings(await getSettings())
})

chrome.tabs.onRemoved.addListener((tabId) => {
  tabHits.delete(tabId)
  tabCosmetic.delete(tabId)
})

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading") {
    tabHits.set(tabId, 0)
    tabCosmetic.set(tabId, 0)
    setBadge(tabId, 0)
  }
  if (changeInfo.url || changeInfo.status === "complete") {
    refreshActionIcon(tabId, tab.url)
  }
})

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null)
  if (tab?.url) refreshActionIcon(tabId, tab.url)
  const total = (tabHits.get(tabId) || 0) + (tabCosmetic.get(tabId) || 0)
  setBadge(tabId, total)
})

if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const tabId = info.request?.tabId
    bumpTab(tabId, "net", 1)
    bumpLifetime(1, 0)
  })
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id ?? -1

  const run = async () => {
    if (message?.type === "qb:get-state") {
      const [settings, stats, tab] = await Promise.all([
        getSettings(),
        getStats(),
        message.tabId
          ? chrome.tabs.get(message.tabId).catch(() => null)
          : sender.tab || null,
      ])
      const url = tab?.url || message.url || ""
      const host = normalizeHost(url)
      return {
        settings,
        stats,
        host,
        url,
        pageWhitelisted: hostMatchesWhitelist(host, settings.whitelist),
        twitchPage: /(?:^|\.)twitch\.tv$/i.test(host),
        twitchEnabled: settings.twitchEnabled !== false,
        pageBlocked:
          (tabHits.get(tab?.id ?? message.tabId ?? tabId) || 0) +
          (tabCosmetic.get(tab?.id ?? message.tabId ?? tabId) || 0),
        pageNet: tabHits.get(tab?.id ?? message.tabId ?? tabId) || 0,
        pageCosmetic: tabCosmetic.get(tab?.id ?? message.tabId ?? tabId) || 0,
      }
    }

    if (message?.type === "qb:set-enabled") {
      const settings = await saveSettings({ enabled: Boolean(message.enabled) })
      await syncDnrFromSettings(settings)
      return { ok: true, settings }
    }

    if (message?.type === "qb:set-twitch") {
      const settings = await saveSettings({ twitchEnabled: Boolean(message.enabled) })
      const on = settings.twitchEnabled !== false
      const tabs = await chrome.tabs.query({ url: ["*://*.twitch.tv/*"] })
      await Promise.all(
        tabs.map(async (tab) => {
          if (!tab.id) return
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              world: "MAIN",
              func: (flag) => {
                try {
                  localStorage.setItem("quietblock-twitch", flag ? "1" : "0")
                } catch {
                  /* private mode */
                }
                document.documentElement.dataset.qbTwitch = flag ? "on" : "off"
              },
              args: [on],
            })
          } catch {
            /* tab inaccessible */
          }
        }),
      )
      return { ok: true, settings }
    }

    if (message?.type === "qb:toggle-site") {
      const settings = await getSettings()
      const host = normalizeHost(message.host)
      if (!host) return { ok: false, error: "Hôte invalide" }
      const set = new Set(settings.whitelist)
      if (set.has(host)) set.delete(host)
      else set.add(host)
      const next = await saveSettings({ whitelist: [...set].sort() })
      await syncDnrFromSettings(next)
      return { ok: true, settings: next, pageWhitelisted: set.has(host) }
    }

    if (message?.type === "qb:save-settings") {
      const next = await saveSettings(message.settings || {})
      await syncDnrFromSettings(next)
      return { ok: true, settings: next }
    }

    if (message?.type === "qb:cosmetic-hits") {
      const n = Number(message.count) || 0
      bumpTab(tabId, "cosmetic", n)
      await bumpLifetime(0, n)
      return { ok: true }
    }

    if (message?.type === "qb:should-run") {
      const settings = await getSettings()
      const host = normalizeHost(message.host || sender.tab?.url || "")
      const runContent =
        settings.enabled && !hostMatchesWhitelist(host, settings.whitelist)
      const twitchHost = /(?:^|\.)twitch\.tv$/i.test(host)
      return {
        run: runContent,
        twitch: runContent && settings.twitchEnabled !== false && twitchHost,
        extraCosmetic: runContent ? settings.extraCosmetic : [],
      }
    }

    if (message?.type === "qb:update-lists") {
      const sources = message.sources || ["easylist", "easyprivacy"]
      let network = []
      let cosmetic = []
      const errors = []
      for (const key of sources) {
        const url = FILTER_SOURCES[key]
        if (!url) continue
        try {
          const res = await fetch(url, { cache: "no-store" })
          if (!res.ok) throw new Error(`${key}: HTTP ${res.status}`)
          const text = await res.text()
          const parsed = parseFilterList(text, DNR_IDS.IMPORT_START + network.length)
          network = network.concat(parsed.network)
          cosmetic = cosmetic.concat(parsed.cosmetic)
        } catch (err) {
          errors.push(String(err?.message || err))
        }
      }
      const uniqueCosmetic = [...new Set(cosmetic)].slice(0, 4000)
      const imported = await replaceImportedRules(network)
      const settings = await saveSettings({
        lastListUpdate: Date.now(),
        importedNetworkCount: imported,
        importedCosmeticCount: uniqueCosmetic.length,
        extraCosmetic: uniqueCosmetic,
      })
      return { ok: errors.length === 0, imported, cosmetic: uniqueCosmetic.length, errors, settings }
    }

    if (message?.type === "qb:clear-imported") {
      const { clearImportedRules } = await import("../utils/dnr.js")
      await clearImportedRules()
      const settings = await saveSettings({
        importedNetworkCount: 0,
        importedCosmeticCount: 0,
        extraCosmetic: [],
        lastListUpdate: 0,
      })
      return { ok: true, settings }
    }

    return { ok: false, error: "Unknown message" }
  }

  run().then(sendResponse).catch((err) => {
    sendResponse({ ok: false, error: String(err?.message || err) })
  })
  return true
})
