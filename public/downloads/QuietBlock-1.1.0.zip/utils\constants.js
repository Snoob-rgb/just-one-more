/** Resource types used by DNR block/allow rules. */
export const RESOURCE_TYPES = [
  "main_frame",
  "sub_frame",
  "stylesheet",
  "script",
  "image",
  "font",
  "object",
  "xmlhttprequest",
  "ping",
  "media",
  "websocket",
  "csp_report",
  "other",
]

export const BLOCK_TYPES = RESOURCE_TYPES.filter((t) => t !== "main_frame")

export const RULESET_IDS = ["ads", "trackers", "annoyances"]

/** Dynamic DNR id ranges (keep disjoint). */
export const DNR_IDS = {
  GLOBAL_ALLOW: 1,
  SITE_ALLOW: 2,
  CUSTOM_BLOCK_START: 100,
  CUSTOM_BLOCK_END: 999,
  IMPORT_START: 1000,
  IMPORT_END: 4999,
}

export const FILTER_SOURCES = {
  easylist: "https://easylist.to/easylist/easylist.txt",
  easyprivacy: "https://easylist.to/easylist/easyprivacy.txt",
  fanboyAnnoyance:
    "https://secure.fanboy.co.nz/fanboy-annoyance.txt",
}

export const DEFAULT_SETTINGS = {
  enabled: true,
  twitchEnabled: true,
  lists: {
    ads: true,
    trackers: true,
    annoyances: true,
  },
  whitelist: [],
  customBlockDomains: [],
  extraCosmetic: [],
  lastListUpdate: 0,
  importedNetworkCount: 0,
  importedCosmeticCount: 0,
}

export const DEFAULT_STATS = {
  lifetimeBlocked: 0,
  lifetimeCosmetic: 0,
}
