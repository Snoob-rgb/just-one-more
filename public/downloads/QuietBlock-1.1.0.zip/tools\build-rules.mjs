/**
 * Génère les règles DNR statiques à partir des listes de domaines.
 * Usage : node tools/build-rules.mjs
 */
import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, "..")

const BLOCK_TYPES = [
  "sub_frame",
  "script",
  "image",
  "font",
  "object",
  "xmlhttprequest",
  "ping",
  "media",
  "websocket",
  "csp_report",
  "other",
]

const adsDomains = `
doubleclick.net googlesyndication.com googleadservices.com googletagservices.com
pagead2.googlesyndication.com ads.google.com ads.google.fr adservice.google.com
adservice.google.fr 2mdn.net g.doubleclick.net ad.doubleclick.net
static.doubleclick.net googleads.g.doubleclick.net partner.googleadservices.com
tpc.googlesyndication.com www.googletagservices.com
amazon-adsystem.com aax.amazon-adsystem.com s.amazon-adsystem.com
c.amazon-adsystem.com fls-na.amazon-adsystem.com fls-eu.amazon-adsystem.com
assoc-amazon.com ads-api.twitter.com ads.twitter.com static.ads-twitter.com
ads-twitter.com ads.linkedin.com px.ads.linkedin.com
adnxs.com ib.adnxs.com secure.adnxs.com cdn.adnxs.com
criteo.com criteo.net static.criteo.net bidder.criteo.com
casalemedia.com pubmatic.com image2.pubmatic.com ads.pubmatic.com
rubiconproject.com fastlane.rubiconproject.com
openx.net openx.com openxcdn.net us-u.openx.net
indexww.com casalemedia.com smartadserver.com eqy.smartadserver.com
teads.tv a.teads.tv outbrain.com widgets.outbrain.com images.outbrain.com
taboola.com cdn.taboola.com trac.taboola.com
revcontent.com trends.revcontent.com mgid.com servicer.mgid.com
zergnet.com media.net contextual.media.net
yieldmo.com toboads.com vidoomy.com unrulymedia.com
spotxchange.com spotx.tv springserve.com lijit.com
contextweb.com bidswitch.net emxdgt.com gumgum.com
triplelift.com sharethrough.com sovrn.com agkn.com
advertising.com adtechus.com adtech.de adform.net adform.com
appnexus.com districtm.io onetag.com s-onetag.com
moatads.com px.moatads.com mookie1.com rfihub.com rlcdn.com
turn.com undertone.com adsafeprotected.com pixel.adsafeprotected.com
adsymptotic.com adzerk.net adzerk.com carbonads.net carbonads.com
buysellads.com servedby-buysellads.com
propellerads.com propellerkit.com popads.net popcash.net popmyads.com
adsterra.com hilltopads.net hilltopads.com exoclick.com exosrv.com
juicyads.com trafficjunky.net trafficjunky.com adcash.com adblade.com
adsnative.com adskeeper.co.uk adskeeper.com ad-maven.com
bidvertiser.com chitika.com clickadu.com
everesttech.net exponential.com fastclick.net mediaforge.com
mediavine.com nativo.com perfectaudience.com simpli.fi sitescout.com
smartclip.net tapad.com thebrighttag.com tradedoubler.com
trafficstars.com tribalfusion.com valueclick.com zedo.com zemanta.com
adgrx.com adhigh.net adingo.jp adkernel.com admanmedia.com admedo.com
admixer.net adotmob.com adpushup.com adriver.ru adroll.com
adsrvr.org adtelligent.com adtrue.com adverticum.net advertserve.com
aerserv.com affec.tv aniview.com anyclip.com appier.net applovin.com
aps.amazon.com atemda.com atdmt.com bittads.com bkrtx.com bluekai.com
bttrack.com connatix.com content.ad conversantmedia.com cpmstar.com
crsspxl.com deepintent.com disqusads.com dotomi.com doubleverify.com
cdn.doubleverify.com dtmpub.com dyntrk.com easydmp.net ebuzzing.com
eqads.com everestjs.net exelator.com extend.tv eyeviewads.com
flashtalking.com fwmrm.net genieesspv.jp innovid.com intentiq.com
ipredictive.com ironsource.com ivitrack.com jivox.com kargo.com
keywee.co liadm.com liveintent.com loopme.me magnite.com
mediaalpha.com mediago.io mediarithmics.com medleyads.com
nend.net nexage.com nuggad.net omnitagjs.com onscroll.com
owneriq.net p-n.io paypopup.com perfectmarket.com polarcdn.com
postrelease.com powerlinks.com primeval.io pro-market.net
pub.network pulsepoint.com q1media.com rambler.ru/ad
reproio.com retargeter.com rhythmone.com richrelevance.com rkdms.com
rmtag.com rtbhouse.com rtbsape.ru rubiconproject.net
sascdn.com sc-static.net sekindo.com sendpulse.com servebom.com
serverbid.com shinystat.com smaato.net smrtb.com snapads.com
sojern.com sonobi.com spotxcdn.com steelhousemedia.com stickyadstv.com
streamrail.com superawesome.tv switchadhub.com swoop.com
tapjoy.com tidaltv.com tinypass.com toboads.com tonefuse.com
tremorhub.com trkn.us tubemogul.com tutoads.tv tynt.com
upsight-api.com usemax.de vungle.com w55c.net webgains.com
weborama.fr weborama.com xad.com xplosion.de yieldlab.net
an.yandex.ru yandexadexchange.net zdbb.net zqtk.net
ads.yahoo.com gemini.yahoo.com analytics.yahoo.com
adserver.yahoo.com ads.msn.com ads.microsoft.com
bat.bing.com adnxs.net 3lift.com 33across.com
adlooxtracking.com adloox.com adotube.com adscale.de
adserverplus.com adsnative.com adspirit.de adsupply.com
adtech.com adtegrity.com advertising.yahoo.com
advertserve.com adxcel-ec2.com adxpose.com adxpremium.services
aralego.com atomex.net audience.rs bannerflow.com
bidr.io bidtheatre.com blismedia.com bouncex.net
brand-display.com brightcom.com broadstreetads.com
btloader.com c1exchange.com cedexis.com company-target.com
connatix.com cpx.to creativecdn.com criteo.net
ctnsnet.com cxense.com dianomi.com digitru.st
e-planning.net easydmp.net emxdgt.com engagebdr.com
ezoic.com ezoic.net flashb.id fyber.com
getpublica.com gmossp-sp.jp gstatic.com/pagead
harvestadsdepot.com histats.com imonomy.com
improvedigital.com incrementx.com infolinks.com
inmobi.com inner-active.mobi invitemedia.com
isoftmarketing.com jumptap.com kixer.com
komoona.com krushmedia.com kumma.com
lifestreet.com lkqd.net lockerdome.com
m6r.eu madsone.com marfeel.com
mathtag.com maxymiser.net media6degrees.com
mediaforge.com medyanetads.com microad.jp
mixpo.com moat.com mobfox.com
mobileadtrading.com mopub.com mxptint.net
nativeads.com nativo.net netseer.com
networld.hk newsmaxfeednetwork.com nextmillennium.io
o333o.com ogury.com onaudience.com
openadstream.com openx.org opera.com/ad
optad360.com outbrainimg.com p161.net
pagefair.com pagefair.net pardot.com/l
paypalobjects.com/tag
piano.io/xbuilder
plista.com pocketmath.com
popin.cc powerad.ai
ppjol.com programmatictrader.com
promo.com proximic.com
pubmine.com pulseadnetwork.com
pushground.com pushnami.com
q1mediahydraplatform.com quantcount.com
r9x.in rapleaf.com
reamp.com.br recsv.net
redintelligence.net reembed.com
refinery89.com relap.io
republika.no revjet.com
revsci.net richaudience.com
rockyou.net roxot-panel.com
rtt.ag rundsp.com
sape.ru sabavision.com
seedtag.com selectablemedia.com
servenobid.com shareasale.com
shop.pe /ads
sitemaji.com slatic.net
smartstream.tv smowtion.com
sociomantic.com sonobi.net
sortable.com speee-ad.jp
sportradarserving.com startapp.com
steelhousemedia.com stickyads.tv
sumome.com superad2.com.sg
supplyframe.com sur.ly
tapnative.com teadstv.com
theadex.com themediagrid.com
themonetizr.com thetrafficstat.net
tidaltv.com tpnads.com
trafmag.com tribalfusion.net
trustx.org tynt.com
ucfunnel.com unbounce.com/visitors
underdog.media valuead.com
vdopia.com veinteractive.com
veruta.com videoadex.com
vidoomy.com viewdeos.com
viralize.tv visx.net
volvelle.tech vrtcal.com
waardex.com webedia-group.com
widearea.co.uk xapads.com
yengo.com yieldlab.com
yieldmanager.com yieldmo.net
zedo.net zergnet.net
`.trim().split(/\s+/).filter(Boolean)

const trackerDomains = `
google-analytics.com ssl.google-analytics.com stats.g.doubleclick.net
analytics.google.com region1.google-analytics.com
hotjar.com static.hotjar.com script.hotjar.com insights.hotjar.com
mixpanel.com api.mixpanel.com cdn.mxpnl.com mxpnl.com
amplitude.com api2.amplitude.com cdn.amplitude.com
segment.io api.segment.io cdn.segment.com
fullstory.com rs.fullstory.com
mouseflow.com cdn.mouseflow.com
clarity.ms www.clarity.ms
heapanalytics.com cdn.heapanalytics.com
quantserve.com pixel.quantserve.com secure.quantserve.com quantcount.com
scorecardresearch.com sb.scorecardresearch.com
imrworldwide.com cdn-gl.imrworldwide.com
comscore.com siterecruit.comscore.com
chartbeat.com static.chartbeat.com ping.chartbeat.net chartbeat.net
mc.yandex.ru metrica.yandex.ru
statcounter.com www.statcounter.com
clicktale.net cdn.clicktale.net
crazyegg.com script.crazyegg.com
inspectlet.com hn.inspectlet.com
luckyorange.com cdn.luckyorange.com
logrocket.com cdn.logrocket.io
hs-analytics.net hsadspixel.net track.hubspot.com
marketo.net munchkin.marketo.net
omtrdc.net sc.omtrdc.net
demdex.net dpm.demdex.net
krxd.net cdn.krxd.net
bluecava.com api.bluecava.com
crwdcntrl.net bcp.crwdcntrl.net
eyeota.net ps.eyeota.net
liadm.com bcp.liadm.com
tapad.com pixel.tapad.com
agkn.com aa.agkn.com
rlcdn.com ids.rlcdn.com
mookie1.com ib.mookie1.com
mathtag.com pixel.mathtag.com
exelator.com loadus.exelator.com
adsymptotic.com p.adsymptotic.com
simpli.fi tag.simpli.fi
sitescout.com pixel.sitescout.com
turn.com ad.turn.com
bidswitch.net x.bidswitch.net
casalemedia.com dsum-sec.casalemedia.com
openx.net us-u.openx.net
pubmatic.com image6.pubmatic.com
rubiconproject.com pixel.rubiconproject.com
contextweb.com bh.contextweb.com
w55c.net i.w55c.net
rfihub.com p.rfihub.com
owneriq.net px.owneriq.net
semasio.net uipglob.semasio.net
nuggad.net rt.nuggad.net
cxense.com cdn.cxense.com
permutive.com api.permutive.com
tealiumiq.com collect.tealiumiq.com
tiqcdn.com tags.tiqcdn.com
ensighten.com nexus.ensighten.com
go-mpulse.net c.go-mpulse.net
parsely.com cdn.parsely.com
globalwebindex.net p.globalwebindex.net
intentiq.com sync.intentiq.com
ipredictive.com sync.ipredictive.com
deepintent.com match.deepintent.com
tribalfusion.com a.tribalfusion.com
adsrvr.org match.adsrvr.org
pixel.facebook.com
analytics.tiktok.com analytics-ipv6.tiktok.com
ads.tiktok.com
snap.licdn.com px.ads.linkedin.com
sc-static.net tr.snapchat.com
tr6.snapchat.com
static.ads-twitter.com
bat.bing.com
cdn.branch.io api2.branch.io
adjust.com app.adjust.com
appsflyer.com launches.appsflyer.com
kochava.com control.kochava.com
singular.net sdk-api-v1.singular.net
hotjar.io
contentsquare.net t.contentsquare.net
quantummetric.com
fullstory.com
mouseflow.com
smartlook.com rec.smartlook.com
inspectlet.com
luckyorange.net
sessioncam.com
userreplay.net
clicktale.com
ptengine.com ptengine.jp
hm.baidu.com
cnzz.com s95.cnzz.com
googleoptimize.com www.googleoptimize.com
vwo.com dev.visualwebsiteoptimizer.com
optimizely.com cdn.optimizely.com
abtasty.com try.abtasty.com
convert.com cdn-3.convertexperiments.com
d.adroll.com s.adroll.com
`.trim().split(/\s+/).filter(Boolean)

const annoyanceDomains = `
popads.net popcash.net popmyads.com propellerads.com
hilltopads.com adsterra.com exoclick.com juicyads.com
pushnami.com pushground.com push.world pushengage.com
pushwoosh.com wonderpush.com
webpushs.com subscribers.com izooto.com
sumo.com sumome.com wisepops.com
optinmonster.com api.optinmonster.com
justuno.com cdn.justuno.com
hellobar.com my.hellobar.com
bouncex.net bouncex.com
privy.com widget.privy.com
aniview.com play.aniview.com
connatix.com vid.connatix.com
fwmrm.net 29773.v.fwmrm.net
spotxchange.com search.spotxchange.com
unrulymedia.com cdn.unrulymedia.com
teads.tv a.teads.tv
vidoomy.com ads.vidoomy.com
mgid.com servicer.mgid.com
revcontent.com trends.revcontent.com
zergnet.com www.zergnet.com
taboola.com/libtrc outbrain.com/widgetV3
`.trim().split(/\s+/).filter(Boolean)

const extraAdFilters = [
  { filter: "||google.com/pagead", types: BLOCK_TYPES },
  { filter: "||google.com/adsense", types: BLOCK_TYPES },
  { filter: "||google.com/aclk", types: BLOCK_TYPES },
  { filter: "||youtube.com/pagead", types: BLOCK_TYPES },
  { filter: "||youtube.com/api/stats/ads", types: ["xmlhttprequest", "ping", "other", "script"] },
  { filter: "||youtube.com/get_midroll", types: ["xmlhttprequest", "other"] },
  { filter: "||facebook.com/tr", types: ["image", "xmlhttprequest", "ping", "script"] },
  { filter: "||connect.facebook.net/en_US/fbevents.js", types: ["script"] },
  { filter: "||connect.facebook.net/en_GB/fbevents.js", types: ["script"] },
  { filter: "||connect.facebook.net/fr_FR/fbevents.js", types: ["script"] },
  { filter: "||imasdk.googleapis.com/js/sdkloader/ima3.js", types: ["script"] },
  { filter: "||securepubads.g.doubleclick.net", types: BLOCK_TYPES },
  { filter: "||pagead2.googlesyndication.com", types: BLOCK_TYPES },
  { filter: "||tpc.googlesyndication.com", types: BLOCK_TYPES },
  { filter: "/adsbygoogle.js", types: ["script"] },
  { filter: "/ads.js", types: ["script"] },
  { filter: "/adframe.", types: ["sub_frame", "script"] },
  { filter: "/ad-banner.", types: ["image", "sub_frame", "script"] },
  { filter: "/sponsored.js", types: ["script"] },
  { filter: "/popunder", types: ["script", "sub_frame"] },
  { filter: "/popup.js", types: ["script"] },
  { filter: "/push-notification-ad", types: ["script"] },
  { filter: "||ads.twitch.tv", types: BLOCK_TYPES },
  { filter: "||static.twitchcdn.net/ads", types: BLOCK_TYPES },
  { filter: "||twitch.tv/ads/", types: ["image", "sub_frame", "script", "xmlhttprequest", "media"] },
]

const extraTrackerFilters = [
  { filter: "||google-analytics.com/analytics.js", types: ["script"] },
  { filter: "||google-analytics.com/ga.js", types: ["script"] },
  { filter: "||google-analytics.com/g/collect", types: ["xmlhttprequest", "ping", "image"] },
  { filter: "||hotjar.com/c/hotjar-", types: ["script"] },
  { filter: "||clarity.ms/tag/", types: ["script"] },
  { filter: "||mc.yandex.ru/metrika", types: BLOCK_TYPES },
  { filter: "||hm.baidu.com/hm.js", types: ["script"] },
]

const extraAnnoyanceFilters = [
  { filter: "||pushwoosh.com", types: BLOCK_TYPES },
  { filter: "||wisepops.com", types: BLOCK_TYPES },
  { filter: "||optinmonster.com", types: BLOCK_TYPES },
  { filter: "||sumo.com", types: BLOCK_TYPES },
  { filter: "/newsletter-popup", types: ["script", "sub_frame"] },
  { filter: "/exit-intent", types: ["script"] },
]

function uniq(list) {
  const seen = new Set()
  const out = []
  for (const item of list) {
    const key = item.toLowerCase().replace(/^www\./, "")
    if (!key || seen.has(key)) continue
    if (key.includes("/") && !key.includes(".")) continue
    seen.add(key)
    out.push(key)
  }
  return out
}

function toRules(entries, extraFilters, startId) {
  const rules = []
  let id = startId
  for (const entry of uniq(entries)) {
    if (entry.includes("/")) {
      rules.push({
        id: id++,
        priority: 1,
        action: { type: "block" },
        condition: { urlFilter: `||${entry}`, resourceTypes: BLOCK_TYPES },
      })
      continue
    }
    rules.push({
      id: id++,
      priority: 1,
      action: { type: "block" },
      condition: { urlFilter: `||${entry}^`, resourceTypes: BLOCK_TYPES },
    })
  }
  for (const extra of extraFilters) {
    rules.push({
      id: id++,
      priority: 2,
      action: { type: "block" },
      condition: { urlFilter: extra.filter, resourceTypes: extra.types },
    })
  }
  return rules
}

function writeRules(name, rules) {
  const file = path.join(root, "rules", name)
  fs.writeFileSync(file, JSON.stringify(rules, null, 2))
  console.log(`${name}: ${rules.length} règles`)
}

fs.mkdirSync(path.join(root, "rules"), { recursive: true })
writeRules("static-ads.json", toRules(adsDomains, extraAdFilters, 1))
writeRules("static-trackers.json", toRules(trackerDomains, extraTrackerFilters, 1))
writeRules("static-annoyances.json", toRules(annoyanceDomains, extraAnnoyanceFilters, 1))
