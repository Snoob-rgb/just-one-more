(() => {
  if (!/(^|\.)twitch\.tv$/i.test(location.hostname)) return
  if (window.__quietblockTwitchGuard) return

  const off =
    document.documentElement?.dataset?.qbTwitch === "off" ||
    (() => {
      try {
        return localStorage.getItem("quietblock-twitch") === "0"
      } catch {
        return false
      }
    })()
  if (off) return

  window.__quietblockTwitchGuard = true

  const CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"
  const BACKUP_TYPES = ["embed", "popout", "autoplay"]
  const TOKEN_HASH = "ed230aa1e33e07eebb8928504583da78a5173989fadfb1ac94be06a04f3cdbe9"
  const ourBlobs = new Set()
  const workers = []
  let lastChannel = ""
  let lastUsherSearch = ""

  const hdr = {
    deviceId: "",
    clientVersion: "",
    clientSession: "",
    integrity: "",
    authorization: "",
    tokenTemplate: null,
  }

  const ping = (count = 1) => {
    try {
      document.dispatchEvent(new CustomEvent("qb-twitch-hit", { detail: { count } }))
    } catch {
      /* ignore */
    }
  }

  const readHeader = (headers, name) => {
    if (!headers) return ""
    if (typeof headers.get === "function") return headers.get(name) || ""
    const key = Object.keys(headers).find((k) => k.toLowerCase() === name.toLowerCase())
    return key ? String(headers[key] || "") : ""
  }

  const captureFromInit = (init) => {
    if (!init?.headers) return
    const h = init.headers
    const device = readHeader(h, "X-Device-Id") || readHeader(h, "Device-ID")
    const version = readHeader(h, "Client-Version")
    const session = readHeader(h, "Client-Session-Id")
    const integrity = readHeader(h, "Client-Integrity")
    const auth = readHeader(h, "Authorization")
    let changed = false
    if (device && device !== hdr.deviceId) {
      hdr.deviceId = device
      changed = true
    }
    if (version && version !== hdr.clientVersion) {
      hdr.clientVersion = version
      changed = true
    }
    if (session && session !== hdr.clientSession) {
      hdr.clientSession = session
      changed = true
    }
    if (integrity && integrity !== hdr.integrity) {
      hdr.integrity = integrity
      changed = true
    }
    if (auth && auth !== hdr.authorization) {
      hdr.authorization = auth
      changed = true
    }
    if (changed) pushHdr()
  }

  const pushHdr = () => {
    for (const w of workers) {
      try {
        w.postMessage({ __qb: 1, k: "hdr", v: { ...hdr } })
      } catch {
        /* worker gone */
      }
    }
  }

  const rewriteTokenBody = (raw) => {
    try {
      const parsed = JSON.parse(raw)
      const items = Array.isArray(parsed) ? parsed : [parsed]
      let changed = false
      for (const item of items) {
        if (!item?.variables || typeof item.variables.playerType !== "string") continue
        if (!hdr.tokenTemplate) hdr.tokenTemplate = item
        if (typeof item.variables.login === "string" && item.variables.login) {
          lastChannel = item.variables.login
        }
        if (item.variables.playerType === "picture-by-picture") {
          item.variables = { ...item.variables, playerType: "popout" }
          changed = true
          continue
        }
        if (item.variables.playerType !== "popout" && item.variables.playerType !== "embed") {
          item.variables = { ...item.variables, playerType: "popout" }
          changed = true
        }
      }
      return changed ? JSON.stringify(Array.isArray(parsed) ? items : items[0]) : null
    } catch {
      return null
    }
  }

  const gqlHeaders = () => {
    const h = { "Client-ID": CLIENT_ID, "Content-Type": "application/json" }
    if (hdr.deviceId) h["X-Device-Id"] = hdr.deviceId
    if (hdr.clientVersion) h["Client-Version"] = hdr.clientVersion
    if (hdr.clientSession) h["Client-Session-Id"] = hdr.clientSession
    if (hdr.integrity) h["Client-Integrity"] = hdr.integrity
    if (hdr.authorization) h["Authorization"] = hdr.authorization
    return h
  }

  const channelFromUsher = (url) => {
    try {
      const u = new URL(url, location.href)
      const m = u.pathname.match(/\/channel\/hls\/([^./]+)\.m3u8/i)
      return m ? decodeURIComponent(m[1]) : ""
    } catch {
      return ""
    }
  }

  const nativeFetch = window.fetch.bind(window)
  window.fetch = function quietblockTwitchFetch(input, init) {
    const url = String(typeof input === "string" ? input : input?.url || "")
    const usherChannel = channelFromUsher(url)
    if (usherChannel) {
      lastChannel = usherChannel
      try {
        lastUsherSearch = new URL(url, location.href).search
      } catch {
        lastUsherSearch = ""
      }
    }
    if (url.includes("gql.twitch.tv") && init) {
      captureFromInit(init)
      if (typeof init.body === "string" && init.body.includes("PlaybackAccessToken")) {
        const nextBody = rewriteTokenBody(init.body)
        if (nextBody) init = { ...init, body: nextBody }
      }
    }
    return nativeFetch(input, init)
  }

  const isAdPlaylist = (text) =>
    typeof text === "string" &&
    (text.includes("stitched") || /X-TV-TWITCH-AD/i.test(text) || text.includes('"MIDROLL"'))

  const stripAdSegments = (text) => {
    const lines = text.replace(/\r/g, "").split("\n")
    const out = []
    let skipUrl = false
    let inAd = false
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i]
      if (
        line.includes("stitched") ||
        /X-TV-TWITCH-AD/i.test(line) ||
        (line.startsWith("#EXT-X-DATERANGE") && /ad/i.test(line))
      ) {
        inAd = true
        continue
      }
      if (line.startsWith("#EXT-X-DISCONTINUITY") && inAd) {
        inAd = false
        continue
      }
      if (line.startsWith("#EXTINF")) {
        const live = line.includes(",live")
        if (inAd || (!live && isAdPlaylist(text))) {
          skipUrl = true
          continue
        }
      }
      if (skipUrl) {
        skipUrl = false
        continue
      }
      out.push(line)
    }
    return out.join("\n")
  }

  const tokenBodyFor = (channel, playerType) => {
    if (hdr.tokenTemplate?.variables) {
      return {
        ...hdr.tokenTemplate,
        variables: {
          ...hdr.tokenTemplate.variables,
          isLive: true,
          login: channel,
          isVod: false,
          vodID: "",
          playerType,
          platform: playerType === "autoplay" ? "android" : "web",
        },
      }
    }
    return {
      operationName: "PlaybackAccessToken",
      variables: {
        isLive: true,
        login: channel,
        isVod: false,
        vodID: "",
        playerType,
        platform: playerType === "autoplay" ? "android" : "web",
      },
      extensions: {
        persistedQuery: { version: 1, sha256Hash: TOKEN_HASH },
      },
    }
  }

  const fetchBackupPlaylist = async (channel, usherSearch, playerType) => {
    const gqlRes = await nativeFetch("https://gql.twitch.tv/gql", {
      method: "POST",
      headers: gqlHeaders(),
      body: JSON.stringify(tokenBodyFor(channel, playerType)),
    })
    if (!gqlRes.ok) return ""
    const json = await gqlRes.json()
    const token = json?.data?.streamPlaybackAccessToken
    if (!token?.signature || !token?.value) return ""
    const usher = new URL(`https://usher.ttvnw.net/api/channel/hls/${encodeURIComponent(channel)}.m3u8`)
    if (usherSearch) {
      new URLSearchParams(usherSearch).forEach((v, k) => {
        if (k !== "sig" && k !== "token") usher.searchParams.set(k, v)
      })
    }
    usher.searchParams.set("sig", token.signature)
    usher.searchParams.set("token", token.value)
    const masterRes = await nativeFetch(usher.href)
    if (!masterRes.ok) return ""
    const master = await masterRes.text()
    const mediaUrls = master
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith("#") && /m3u8/i.test(l))
      .map((l) => {
        try {
          return new URL(l, usher.href).href
        } catch {
          return l
        }
      })
    if (!mediaUrls.length) return isAdPlaylist(master) ? "" : master
    for (const mediaUrl of mediaUrls) {
      try {
        const mediaRes = await nativeFetch(mediaUrl)
        if (!mediaRes.ok) continue
        const text = await mediaRes.text()
        if (text && !isAdPlaylist(text)) return text
      } catch {
        /* next variant */
      }
    }
    return ""
  }

  const cleanPlaylist = async (url, text, hint = {}) => {
    const channel =
      hint.channel ||
      channelFromUsher(url) ||
      hdr.tokenTemplate?.variables?.login ||
      lastChannel
    let usherSearch = hint.usherSearch || lastUsherSearch
    try {
      if (!usherSearch && /usher\.ttvnw\.net/i.test(url)) {
        usherSearch = new URL(url, location.href).search
      }
    } catch {
      /* keep previous */
    }
    if (channel) lastChannel = channel
    if (usherSearch) lastUsherSearch = usherSearch
    if (channel) {
      for (const type of BACKUP_TYPES) {
        try {
          const backup = await fetchBackupPlaylist(channel, usherSearch, type)
          if (backup && !isAdPlaylist(backup)) {
            ping(1)
            return backup
          }
        } catch {
          /* try next player type */
        }
      }
    }
    const stripped = stripAdSegments(text)
    if (stripped && stripped !== text) ping(1)
    return stripped || text
  }

  const workerRuntimeSrc = `
self.__qbTwitch = true;
const __qbNativeFetch = fetch.bind(self);
const __qbPending = new Map();
let __qbChannel = "";
let __qbUsherSearch = "";
self.addEventListener("message", (e) => {
  const d = e.data;
  if (!d || d.__qb !== 1) return;
  if (d.k === "cleanRes") {
    const p = __qbPending.get(d.id);
    if (!p) return;
    __qbPending.delete(d.id);
    d.err ? p.reject(new Error(d.err)) : p.resolve(d.body);
  }
});
const __qbIsAd = (t) => typeof t === "string" && (t.includes("stitched") || /X-TV-TWITCH-AD/i.test(t) || t.includes('"MIDROLL"'));
const __qbStrip = (text) => {
  const lines = text.replace(/\\r/g, "").split("\\n");
  const out = [];
  let skipUrl = false;
  let inAd = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes("stitched") || /X-TV-TWITCH-AD/i.test(line) || (line.startsWith("#EXT-X-DATERANGE") && /ad/i.test(line))) {
      inAd = true;
      continue;
    }
    if (line.startsWith("#EXT-X-DISCONTINUITY") && inAd) { inAd = false; continue; }
    if (line.startsWith("#EXTINF")) {
      const live = line.includes(",live");
      if (inAd || (!live && __qbIsAd(text))) { skipUrl = true; continue; }
    }
    if (skipUrl) { skipUrl = false; continue; }
    out.push(line);
  }
  return out.join("\\n");
};
self.fetch = async function(input, init) {
  const url = String(typeof input === "string" ? input : (input && input.url) || "");
  const chMatch = url.match(/\\/channel\\/hls\\/([^./]+)\\.m3u8/i);
  if (chMatch) {
    try { __qbChannel = decodeURIComponent(chMatch[1]); } catch { __qbChannel = chMatch[1]; }
    try { __qbUsherSearch = new URL(url).search; } catch {}
  }
  const res = await __qbNativeFetch(input, init);
  if (!/m3u8/i.test(url)) return res;
  const text = await res.clone().text();
  if (!__qbIsAd(text)) return res;
  self.postMessage({ __qb: 1, k: "ad" });
  const id = Math.random().toString(36).slice(2);
  const cleaned = await new Promise((resolve, reject) => {
    __qbPending.set(id, { resolve, reject });
    self.postMessage({ __qb: 1, k: "clean", id, url, text, channel: __qbChannel, usherSearch: __qbUsherSearch });
    setTimeout(() => {
      if (__qbPending.has(id)) {
        __qbPending.delete(id);
        resolve(__qbStrip(text));
      }
    }, 8000);
  });
  return new Response(cleaned, { status: res.status, statusText: res.statusText, headers: res.headers });
};
`

  const readWorkerSource = (url) => {
    const xhr = new XMLHttpRequest()
    xhr.open("GET", url, false)
    xhr.send()
    return xhr.responseText || ""
  }

  const isTwitchWorkerUrl = (value) => {
    const raw = String(value || "")
    if (ourBlobs.has(raw) || raw.includes("__qb_twitch_worker")) return false
    try {
      const u = new URL(raw, location.href)
      if (u.protocol === "blob:") return true
      return /twitch\.tv$|\.ttvnw\.net$|twitchcdn\.net$/i.test(u.hostname)
    } catch {
      return false
    }
  }

  const NativeWorker = window.Worker
  window.Worker = class QuietBlockTwitchWorker extends NativeWorker {
    constructor(scriptURL, options) {
      if (!isTwitchWorkerUrl(scriptURL)) {
        super(scriptURL, options)
        return
      }
      let source = ""
      try {
        source = readWorkerSource(scriptURL)
      } catch {
        super(scriptURL, options)
        return
      }
      const code = `/*__qb_twitch_worker*/\n${workerRuntimeSrc}\n${source}`
      const blob = URL.createObjectURL(new Blob([code], { type: "text/javascript" }))
      ourBlobs.add(blob)
      super(blob, options)
      workers.push(this)
      this.addEventListener("message", (event) => {
        const d = event.data
        if (!d || d.__qb !== 1) return
        if (d.k === "ad") ping(1)
        if (d.k === "clean") {
          if (d.channel) lastChannel = d.channel
          if (d.usherSearch) lastUsherSearch = d.usherSearch
          cleanPlaylist(d.url, d.text, { channel: d.channel, usherSearch: d.usherSearch })
            .then((body) => {
              try {
                this.postMessage({ __qb: 1, k: "cleanRes", id: d.id, body })
              } catch {
                /* ignore */
              }
            })
            .catch((err) => {
              try {
                this.postMessage({
                  __qb: 1,
                  k: "cleanRes",
                  id: d.id,
                  err: String(err?.message || err),
                })
              } catch {
                /* ignore */
              }
            })
        }
      })
      pushHdr()
    }
  }

  try {
    Object.defineProperty(document, "visibilityState", {
      get() {
        return "visible"
      },
    })
    Object.defineProperty(document, "hidden", {
      get() {
        return false
      },
    })
  } catch {
    /* some browsers lock these */
  }
})()
