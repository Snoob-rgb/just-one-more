const $ = (id) => document.getElementById(id)

function lines(text) {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim().replace(/^www\./, "").toLowerCase())
    .filter(Boolean)
}

function fill(settings) {
  $("list-ads").checked = settings.lists.ads
  $("list-trackers").checked = settings.lists.trackers
  $("list-annoyances").checked = settings.lists.annoyances
  $("twitchEnabled").checked = settings.twitchEnabled !== false
  $("whitelist").value = (settings.whitelist || []).join("\n")
  $("customBlock").value = (settings.customBlockDomains || []).join("\n")
  if (settings.lastListUpdate) {
    const d = new Date(settings.lastListUpdate).toLocaleString("fr-FR")
    $("importMeta").textContent =
      `Import : ${settings.importedNetworkCount} règles réseau + ${settings.importedCosmeticCount} filtres cosmétiques (${d}).`
  } else {
    $("importMeta").textContent = "Aucune liste externe importée. Les listes embarquées restent actives."
  }
}

async function load() {
  const state = await chrome.runtime.sendMessage({ type: "qb:get-state" })
  fill(state.settings)
}

$("save").addEventListener("click", async () => {
  $("saveStatus").textContent = "Enregistrement…"
  const res = await chrome.runtime.sendMessage({
    type: "qb:save-settings",
    settings: {
      lists: {
        ads: $("list-ads").checked,
        trackers: $("list-trackers").checked,
        annoyances: $("list-annoyances").checked,
      },
      twitchEnabled: $("twitchEnabled").checked,
      whitelist: lines($("whitelist").value),
      customBlockDomains: lines($("customBlock").value),
    },
  })
  if (res?.ok) {
    fill(res.settings)
    $("saveStatus").textContent = "Enregistré."
  } else {
    $("saveStatus").textContent = res?.error || "Erreur."
  }
})

$("updateLists").addEventListener("click", async () => {
  $("updateLists").disabled = true
  $("updateStatus").textContent = "Téléchargement EasyList / EasyPrivacy…"
  const res = await chrome.runtime.sendMessage({
    type: "qb:update-lists",
    sources: ["easylist", "easyprivacy"],
  })
  $("updateLists").disabled = false
  if (res?.ok) {
    fill(res.settings)
    $("updateStatus").textContent =
      `OK — ${res.imported} règles réseau, ${res.cosmetic} sélecteurs cosmétiques.`
  } else {
    $("updateStatus").textContent =
      `Échec partiel : ${(res?.errors || []).join(" · ") || res?.error || "erreur réseau"}`
    if (res?.settings) fill(res.settings)
  }
})

$("clearImported").addEventListener("click", async () => {
  const res = await chrome.runtime.sendMessage({ type: "qb:clear-imported" })
  if (res?.settings) fill(res.settings)
  $("updateStatus").textContent = "Listes importées retirées."
})

load()
